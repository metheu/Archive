#pragma once

#define GIT_TAG "3.3.1"
#define GIT_TAG_NAMESPACE v3_3_1
